from json import dumps, loads
from os.path import dirname
from platform import system
from random import choice
from sys import exc_info
from threading import Thread
from time import sleep

from requests import get, post

cwd = dirname(__file__)

if system().lower() == "windows":
    from ctypes import windll

    kernel32 = windll.kernel32
    kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)

class fore:

    Black = "\u001b[30m"
    Red = "\u001b[31m"
    Green = "\u001b[32m"
    Yellow = "\u001b[33m"
    Blue = "\u001b[34m"
    Magenta = "\u001b[35m"
    Cyan = "\u001b[36m"
    White = "\u001b[37m"

    Bright_Black = "\u001b[30;1m"
    Bright_Red = "\u001b[31;1m"
    Bright_Green = "\u001b[32;1m"
    Bright_Yellow = "\u001b[33;1m"
    Bright_Blue = "\u001b[34;1m"
    Bright_Magenta = "\u001b[35;1m"
    Bright_Cyan = "\u001b[36;1m"
    Bright_White = "\u001b[37;1m"


class back:

    Black = "\u001b[40m"
    Red = "\u001b[41m"
    Green = "\u001b[42m"
    Yellow = "\u001b[43m"
    Blue = "\u001b[44m"
    Magenta = "\u001b[45m"
    Cyan = "\u001b[46m"
    White = "\u001b[47m"

    Bright_Black = "\u001b[40;1m"
    Bright_Red = "\u001b[41;1m"
    Bright_Green = "\u001b[42;1m"
    Bright_Yellow = "\u001b[43;1m"
    Bright_Blue = "\u001b[44;1m"
    Bright_Magenta = "\u001b[45;1m"
    Bright_Cyan = "\u001b[46;1m"
    Bright_White = "\u001b[47;1m"


class style:

    Bold = "\033[1m"
    Faint = "\033[2m"
    Italic = "\033[3m"
    Underlined = "\033[4m"
    Negative = "\033[7m"
    Crossed = "\033[9m"
    RESET_ALL = "\u001b[0m"

response = {}
trivia_file = open(f"{cwd}../../trivia.json", "r+", errors="ignore")
trivia = loads(trivia_file.read())

def run(token: str, channel_id: int) -> None:
    global trivia
    
    while True:
        try:
            post(
                f"https://discord.com/api/v10/channels/{channel_id}/messages?limit=1",
                headers={"authorization": token},
                json={"content": "pls trivia"},
            )

            sleep(1)

            response = loads(
                get(
                    f" https://discord.com/api/v10/channels/{channel_id}/messages",
                    headers={"authorization": token},
                ).content.decode()
            )[0]

            try:
                answer = trivia[
                    response["embeds"][0]["description"]
                    .split("\n")[0]
                    .replace("*", "")
                    .replace('"', "&quot;")
                ].replace("&quot;", '"')
            except KeyError:
                answer = None
                
            custom_id = None

            for index, possible_answer in enumerate(
                response["components"][0]["components"]
            ):
                if possible_answer["label"] == answer:
                    custom_id = response["components"][0]["components"][index][
                        "custom_id"
                    ]

            if custom_id is None:
                custom_id = choice(response["components"][0]["components"])["custom_id"]

            payload = {
                "application_id": 270904126974590976,
                "channel_id": channel_id,
                "type": 3,
                "data": {"component_type": 2, "custom_id": custom_id},
                "guild_id": response["message_reference"]["guild_id"],
                "message_flags": 0,
                "message_id": response["id"],
                "session_id": "a",
            }

            post(
                "https://discord.com/api/v10/interactions",
                headers={"authorization": token},
                json=payload,
            )

            sleep(0.5)

            response = loads(
                get(
                    f" https://discord.com/api/v10/channels/{channel_id}/messages",
                    headers={"authorization": token},
                ).content.decode()
            )[0]

            question = (
                response["embeds"][0]["description"]
                .split("\n")[0]
                .replace("*", "")
                .replace('"', "&quot;")
            )

            for button in response["components"][0]["components"]:
                if button["style"] == 3:
                    print(f"\n{f'{style.Bold + style.Underlined + fore.Bright_Green}KNOWN QUESTION{style.RESET_ALL}' if question in trivia.keys() else f'{style.Bold + style.Underlined + fore.Bright_Red}UNKNOWN QUESTION{style.RESET_ALL}'}\n{style.Underlined}{style.Bold}{fore.Bright_Magenta}Question:{style.RESET_ALL} `{question}`.\n{style.Underlined}{style.Bold}{fore.Bright_White}Answer:{style.RESET_ALL} `{answer}`.")
                    answer = button["label"].replace('"', "&quot;")
                    trivia[question] = answer
                    break

            trivia_file.seek(0)
            trivia_file.truncate()
            trivia_file.write(dumps(trivia))
            trivia_file.flush()
        except Exception:
            print(f"\n{style.Bold + style.Underlined + fore.Bright_Red}ERROR{style.RESET_ALL}\n{exc_info()}\n{response}")
            sleep(15)

        sleep(5)

tokens = ["OTY3NzUxMDkwOTA3MDA5MDY0.GGaKDw.KD8YnW7HXZ73jQGVV2O9tkkggQokVtpMqSGIuA", "OTc1Mzc4NTQ5MzcwMzkyNjE2.GllwDM.Qbd35VXjZukjf0a6cinE9BSsPqi3GcdXDyQh5E", "OTc1Mzc3NzYxNDExNjkwNTE2.GHyWbb.hkUSyROGI5QEJPnJaN7Y3Uo46xr7CmFxBhapxo"]
channel_ids = [975376507310604358, 975379071598997535, 975378148936011826]

for index in range(len(tokens)):
    Thread(target=run, args=[tokens[index], channel_ids[index]]).start()