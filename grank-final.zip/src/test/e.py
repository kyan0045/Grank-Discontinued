from copy import copy
from json import loads
from threading import Thread
from time import sleep

from requests import delete, get, post

tokens = ["NzM4MzM5Mjg3MjMzMjAwMTI4.GtSM1e.CU_LdZpqqenAzCzqT7BPJ9ZMBJr79Uhy9Q8SZE", "OTY3NzUxMDkwOTA3MDA5MDY0.GGaKDw.KD8YnW7HXZ73jQGVV2O9tkkggQokVtpMqSGIuA"]
channel_ids = [975345156406542336, 975345156406542336]

def get_msg(token: str, channel_id: str) -> dict:
    req = get(
        f"https://discord.com/api/v10/channels/{channel_id}/messages",
        headers={"authorization": token},
    )

    response = loads(req.content.decode())

    if req.status_code == 429:
        print(f"Failed to get latest msg. Retrying after {response['retry_after']}.")
        sleep(response["retry_after"])
        return get_msg()    
    
    print("Got latest msg.")
    return response[0]

def send_msg(token: str, channel_id: str, msg: str, typing: bool=True) -> dict:
    if typing:
        post(
            f"https://discord.com/api/v9/channels/{channel_id}/typing",
            headers={"authorization": token},
        )
        
        print("Sent typing status.")
        
        sleep(len(msg)/20)
            
    req = post(
        f"https://discord.com/api/v10/channels/{channel_id}/messages",
        headers={"authorization": token},
        json={"content": msg}
    )
    
    response = loads(req.content.decode())

    if req.status_code == 429:
        print(f"Failed to send msg. Retrying after {response['retry_after']}.")
        sleep(response["retry_after"])
        return send_msg(token, channel_id, msg, typing)    
    
    print("Sent msg.")
    return response

def delete_msg(token: str, channel_id: str, msg_id: str) -> None:
    req = delete(
        f"https://discord.com/api/v9/channels/{channel_id}/messages/{msg_id}",
        headers={"authorization": token},
    )
    
    if req.status_code == 429:
        response = loads(req.content.decode())
        
        print(f"Failed to delete msg. Retrying after {response['retry_after']}.")
        sleep(response["retry_after"])
        return delete(msg_id)    
    
    print("Deleted msg.")

def run(token: str, channel_id: int) -> None:
    req = get(
        "https://discord.com/api/v10/users/@me",
        headers={"authorization": token},
    )
    
    ID = loads(req.content.decode())["id"]

    old_msg = get_msg(token, channel_id)

    while True:    
        msg = get_msg(token, channel_id)
        
        if msg["content"] == old_msg["content"]:
            sleep(1)
            continue
        
        if msg["author"]["id"] == ID:
            old_msg = copy(msg)
            sleep(1)
            continue
        
        if msg["content"] != "e" * len(msg["content"]) or len(msg["content"]) != len(old_msg["content"])+1:
            delete_msg(token, channel_id, msg["id"])
            continue
        
        send_msg(token, channel_id, f"{msg['content']}e")
        old_msg = copy(msg)
        
for index in range(len(tokens)):
    Thread(target=run, args=[tokens[index], channel_ids[index]]).start()