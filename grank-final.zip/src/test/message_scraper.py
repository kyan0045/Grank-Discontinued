from json import loads

from requests import get

req = get("https://discord.com/api/v10/channels/975376494580887613/messages", headers={"authorization": "NzM4MzM5Mjg3MjMzMjAwMTI4.GBK5Xg.-LEGzXwc0Rr30KzlDev4i9bM30pNNS1E_cXUSg"})

print(loads(req.content.decode())[0])