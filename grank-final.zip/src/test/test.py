text = "<@738339287233200128> bought 1x **Shovel** <:IronShovel:868263822035669002> and paid `⏣ 25,000`"

print([word for word in text.split(" ") if word[:2] == "<:"][0].split(":")[-1][:-1])