# ⚠️ WARNING!
Do not edit the files, folders and subfolders in this directory if you do not know what you are doing. Doing so will discrupt Grank and cause unwanted issues.

## Templates directory
The templates directory is the basis of the database files for every acount. You can, if you want, edit the files in the `templates/` dir as a sort of master config & database.
